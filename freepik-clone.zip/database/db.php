<?php
// Database connection configuration

// Include configuration if not already included
if (!defined('ENVIRONMENT')) {
    include_once __DIR__ . '/../config/config.php';
}

$servername = "134.255.180.96";
$username = "pixahunt_test";
$password = "pixahunt_test";
$database = "pixahunt_test";

// Set connection timeout to prevent long hangs
ini_set('default_socket_timeout', 5);

// Attempt database connection with error handling
try {
    $dbcon = @mysqli_connect($servername, $username, $password, $database);

    if (!$dbcon) {
        $error = mysqli_connect_error();

        // Log error securely
        if (ENVIRONMENT === 'development') {
            error_log("Database connection failed: " . $error);
        }

        // Set $dbcon to null instead of dying
        $dbcon = null;

        // In production, don't expose connection details
        if (ENVIRONMENT === 'production') {
            // Silently fail - let calling code handle it
        } else {
            // Development: Show helpful error
            if (php_sapi_name() !== 'cli') {
                http_response_code(503);
                die("Database connection failed. Please check your database configuration in db.php");
            }
        }
    } else {
        // UTF-8 support for international characters
        mysqli_set_charset($dbcon, "utf8mb4");
    }
} catch (mysqli_sql_exception $e) {
    // Handle mysqli exceptions
    if (ENVIRONMENT === 'development') {
        error_log("Database connection exception: " . $e->getMessage());
    }

    $dbcon = null;

    if (ENVIRONMENT !== 'production' && php_sapi_name() !== 'cli') {
        http_response_code(503);
        die("Database connection error. Please check your database configuration.");
    }
} catch (Exception $e) {
    // Handle any other exceptions
    if (ENVIRONMENT === 'development') {
        error_log("Database connection error: " . $e->getMessage());
    }

    $dbcon = null;
}

// Sanitize user input to prevent SQL injection
function escape_input($dbcon, $input)
{
    return isset($input) ? mysqli_real_escape_string($dbcon, $input) : '';
}
