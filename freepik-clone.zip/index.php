﻿<?php header('Location: public/index.php?' . $_SERVER['QUERY_STRING']);
exit();